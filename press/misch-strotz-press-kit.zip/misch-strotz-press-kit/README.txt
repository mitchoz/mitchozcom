Misch Strotz: press kit
https://www.mitchoz.com/press/

Free to use for articles, interviews, podcasts, and event or speaker announcements
featuring Misch Strotz.

Questions or higher resolutions: misch@msh.lu
